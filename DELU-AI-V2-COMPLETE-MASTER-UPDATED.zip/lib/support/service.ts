export type Ticket={id:string,userId:string,title:string,details:string,status:"OPEN"|"RESOLVED"|"ESCALATED";resolvedBy?:"DELU"|"OWNER";createdAt:string,resolvedAt?:string};
const tickets:Ticket[]=[];const safePatterns=[/cache/i,/refresh/i,/stale data/i,/notification/i];
export function createTicket(userId:string,title:string,details:string){const t:Ticket={id:crypto.randomUUID(),userId,title,details,status:"OPEN",createdAt:new Date().toISOString()};tickets.push(t);return t}
export function attemptSafeAutoResolve(t:Ticket){if(safePatterns.some(p=>p.test(t.title+" "+t.details))){t.status="RESOLVED";t.resolvedBy="DELU";t.resolvedAt=new Date().toISOString();return true}return false}
export function ownerResolve(id:string){const t=tickets.find(x=>x.id===id);if(!t)return null;t.status="RESOLVED";t.resolvedBy="OWNER";t.resolvedAt=new Date().toISOString();return t}
export function listTickets(){return tickets}
