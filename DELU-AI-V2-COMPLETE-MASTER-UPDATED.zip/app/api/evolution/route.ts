import {NextResponse} from "next/server"; import {proposeEvolution} from "@/lib/evolution/policy";
export async function GET(){return NextResponse.json(proposeEvolution())}
