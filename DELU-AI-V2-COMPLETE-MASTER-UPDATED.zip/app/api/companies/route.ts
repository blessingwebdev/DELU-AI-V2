import {NextResponse} from "next/server"; import {discoverCompanies} from "@/lib/market/registry";
export async function GET(){try{const companies=await discoverCompanies();return NextResponse.json({count:companies.length,companies})}catch(e){return NextResponse.json({error:String((e as Error).message||e)},{status:502})}}
