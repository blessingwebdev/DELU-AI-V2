import {NextResponse} from "next/server"; import {getMarketHealth} from "@/lib/market/service";
export async function GET(){return NextResponse.json({ok:true,service:"DELU AI V2",market:await getMarketHealth(),timestamp:new Date().toISOString()})}
