import {syncMarket} from "@/lib/market/service";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const symbols = (url.searchParams.get("symbols") || "")
    .split(",")
    .map(s => s.trim().toUpperCase())
    .filter(Boolean)
    .slice(0, 300);

  try {
    const snapshot = await syncMarket(symbols);
    return Response.json(snapshot, {headers: {"Cache-Control": "no-store"}});
  } catch (error) {
    return Response.json({ok: false, error: String((error as Error)?.message ?? error)}, {status: 502});
  }
}
