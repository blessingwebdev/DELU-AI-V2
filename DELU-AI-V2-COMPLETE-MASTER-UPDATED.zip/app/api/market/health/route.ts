import {getMarketHealth} from "@/lib/market/service";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(getMarketHealth(), {headers: {"Cache-Control": "no-store"}});
}
