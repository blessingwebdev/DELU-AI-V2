import { listSecurities } from "@/lib/market/service";
export default async function Explorer() {
 const securities = await listSecurities();
 return <main className="mx-auto max-w-7xl px-6 py-10"><h1 className="text-3xl font-bold">NGX Explorer</h1>
 <p className="mt-2 opacity-60">A–Z security directory. Live values appear only after a verified provider sync.</p>
 <div className="mt-6 overflow-x-auto rounded-2xl border bg-white"><table className="w-full text-left text-sm"><thead><tr className="border-b"><th className="p-4">Symbol</th><th className="p-4">Company</th><th className="p-4">Price</th><th className="p-4">Source</th></tr></thead>
 <tbody>{securities.map(s=><tr className="border-b last:border-0" key={s.symbol}><td className="p-4 font-semibold">{s.symbol}</td><td className="p-4">{s.name}</td><td className="p-4">{s.price ?? "—"}</td><td className="p-4">{s.source ?? "Not synced"}</td></tr>)}</tbody></table></div>
 </main>
}
