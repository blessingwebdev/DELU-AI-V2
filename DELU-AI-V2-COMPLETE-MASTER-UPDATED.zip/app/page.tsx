import Link from "next/link";

const modules = [
  ["Dashboard","/dashboard"],["NGX Explorer","/explorer"],["Ask DELU","/ask-delu"],
  ["News","/news"],["PRO","/pro"],["Support","/support"]
];

export default function Home() {
  return <main className="min-h-screen">
    <header className="border-b bg-white/80">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <div><div className="text-xl font-bold" style={{color:"var(--wine)"}}>DELU AI</div>
        <div className="text-xs">NGX Market Intelligence</div></div>
        <Link className="rounded-xl px-4 py-2 text-white" style={{background:"var(--wine)"}} href="/dashboard">Open Dashboard</Link>
      </div>
    </header>
    <section className="mx-auto max-w-7xl px-6 py-20">
      <p className="mb-3 text-sm font-semibold uppercase tracking-widest" style={{color:"var(--gold)"}}>DELU AI V2</p>
      <h1 className="max-w-3xl text-5xl font-bold leading-tight">Understand the NGX. Research with evidence. Ask DELU.</h1>
      <p className="mt-6 max-w-2xl text-lg opacity-75">A structured foundation for verified market data, company intelligence, news, research, education and a human-friendly Nigerian market coach.</p>
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {modules.map(([name,href]) => <Link key={href} href={href} className="rounded-2xl border bg-white p-6 shadow-sm hover:shadow-md">
          <div className="font-semibold">{name}</div><div className="mt-2 text-sm opacity-60">Open module →</div>
        </Link>)}
      </div>
    </section>
  </main>
}
